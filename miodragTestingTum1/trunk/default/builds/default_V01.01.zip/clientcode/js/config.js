var APP = {
	FU_URI: "",
	EXISTING_LANGUAGES : ["en"],
	LANGUAGE_RESOURCES: {
		"en": "http://localhost/testing_scas/resources/miodragTestingTum1AppType/en.json"
	},
	DEFAULT_LANGUAGE : "en",
	APP_TYPE_PROJ : "http://localhost/testing_scas/resources/TasorProjects/miodragTestingTum1AppType",
	APP_KB_PROJ : "http://localhost/testing_scas/resources/TasorProjects/miodragTestingTum1AppKB",
	APP_ONTOS_PROJ : "http://localhost/testing_scas/resources/TasorProjects/miodragTestingTum1AppOntos",
	APP_KB_WDS: "http://localhost/testing_scas/resources/TasorProjects/miodragTestingTum1AppKB_WDS",
    APP_KB_DELETE_DS: "http://localhost/testing_scas/resources/TasorProjects/miodragTestingTum1AppKB_WDS_deletedResources",
	EXT_LINKS : {},
};
