if(APP.APP_NAMES) {
	APP.APP_NAMES.FEEDBACK = {
		"uri": "http://dev.virtuona.rs/virtdev_scas/resources/TasorUnitManagerAppKB/RIDd395ab84-c753-4f8f-9f14-de106b06301c",
		"name": "https://www.planmeout.com/virtuona/TWCFeedbackdefault"
	}
} else {
	APP.APP_NAMES = {
		"FEEDBACK": {
			"uri": "http://dev.virtuona.rs/virtdev_scas/resources/TasorUnitManagerAppKB/RIDd395ab84-c753-4f8f-9f14-de106b06301c",
			"name": "https://www.planmeout.com/virtuona/TWCFeedbackdefault"
		}
	}
}